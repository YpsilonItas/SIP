"""Identita condivise dei campionati; gli alias restano limitati allo sport."""
import json
import re
import unicodedata
from pathlib import Path

COMPETITIONS = json.loads((Path(__file__).parent / "resources/competitions.json").read_text(encoding="utf-8"))


def normalized(name):
    text = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode().lower()
    return " ".join(re.sub(r"[^a-z0-9]+", " ", text).split())


ALIASES = {(row["sport"], normalized(alias)): row["name"] for row in COMPETITIONS for alias in row["aliases"] if alias}


def canonical_league(name, sport):
    return ALIASES.get((sport, normalized(name)), " ".join(name.split()))
