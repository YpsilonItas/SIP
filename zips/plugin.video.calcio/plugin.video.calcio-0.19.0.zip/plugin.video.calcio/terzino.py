"""Terzino event IDs and public Kodi-compatible streams."""
import json
import math
import re
from datetime import datetime
from urllib.parse import urlsplit, urlencode

import zico
from events import SourceError, fetch_page, http_url, event_image, matches_football, USER_AGENT

BASE = "https://terzino.direttecommunity.online/"
SPORTS = {**zico.SPORTS, "Football americano": "AmericanFootball", "Hockey": "IceHockey", "UFC": "MMA", "F1": "Motor"}


def get_events(sport):
    try:
        data = json.loads(fetch_page(BASE + "api/events.php", BASE)[0])
        if not isinstance(data, dict) or not isinstance(data.get("events"), list):
            raise ValueError()
    except (ValueError, OSError) as exc:
        raise SourceError("Terzino schedule is unavailable or has changed format.") from exc
    rows = []
    seen = set()
    for row in data["events"]:
        if not isinstance(row, dict) or row.get("sport") != SPORTS[sport] or row.get("status") not in ("live", "scheduled"):
            continue
        key, title, league, timestamp = row.get("id"), row.get("title"), str(row.get("league") or ""), row.get("start_ts")
        if not isinstance(key, str) or not re.fullmatch(r"[a-zA-Z0-9_-]{1,100}", key) or key in seen or not isinstance(title, str) or not title.strip():
            continue
        if isinstance(timestamp, bool) or not isinstance(timestamp, (int, float)) or not math.isfinite(timestamp):
            continue
        if not matches_football(sport, league, title) or (sport == "UFC" and "UFC" not in league.upper()) or (sport == "F1" and not re.search(r"\bF1\b|FORMULA (?:1|ONE)", league, re.I)):
            continue
        try:
            time = datetime.fromtimestamp(timestamp).strftime("%d/%m %H:%M")
        except (ValueError, OverflowError, OSError):
            continue
        rows.append({"key":"terzino:" + key, "title":title.strip(), "league":league.strip() or "Other competitions",
                     "sport":sport, "timestamp":timestamp, "time":time,
                     "image":event_image(sport, BASE, row.get("home_team_badge"), row.get("away_team_badge")),
                     "streams":row.get("streams", [])})
        seen.add(key)
    return sorted(rows, key=lambda row: row["timestamp"])


def get_sources(key, sport):
    row = next((row for row in get_events(sport) if row["key"] == key), None)
    if not row:
        raise SourceError("This event has left the Terzino schedule. Reopen the category.")
    if not isinstance(row["streams"], list):
        raise SourceError("Invalid Terzino player list.")
    result = []
    confirmed = None
    for stream in row["streams"]:
        if not isinstance(stream, dict) or stream.get("is_premium"):
            continue
        url = stream.get("url")
        if not isinstance(url, str) or any(c in url for c in "<>\r\n"):
            continue
        parsed = urlsplit(url)
        if parsed.scheme != "https" or not parsed.hostname:
            continue
        if parsed.netloc == urlsplit(zico.BASE).netloc and re.fullmatch(r"/api/player/[0-9]+", parsed.path):
            match = re.fullmatch(r"terzino:zt_([1-9][0-9]*)", key)
            if not match:
                continue
            if confirmed is None:
                try:
                    confirmed = zico.get_sources("zico:" + match[1], sport)
                except SourceError:
                    confirmed = []
            if url not in confirmed:
                continue
        elif not parsed.path.endswith(".m3u8"):
            continue
        if url not in result:
            result.append(url)
    if not result and row["streams"]:
        raise SourceError("Terzino has no compatible public player for this match. Web-only, premium or unconfirmed players are not supported.")
    return sorted(result)


def resolve_event(key, sport, source_index=0, source_url=None):
    sources = get_sources(key, sport)
    if source_url is not None:
        if source_url not in sources:
            raise SourceError("The selected player is no longer available. Reopen the match.")
        source_index = sources.index(source_url)
    if not 0 <= source_index < len(sources):
        raise SourceError("No Terzino player is available yet.")
    url = sources[source_index]
    if urlsplit(url).netloc == urlsplit(zico.BASE).netloc:
        return zico.resolve_player(url)
    return http_url(url) + "|" + urlencode({"User-Agent":USER_AGENT, "Referer":BASE})
