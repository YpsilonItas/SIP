"""Shared sport, artwork and HTTP helpers."""
import re
from pathlib import Path
from ssl import SSLCertVerificationError
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit
from urllib.request import Request, urlopen

SPORTS = {"Calcio maschile": "soccer", "Calcio femminile": "soccer", "Pallavolo": "volleyball", "Football americano": "football", "Basket": "basketball",
          "Hockey": "hockey", "Baseball": "baseball", "UFC": "combat", "F1": "racing"}
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/121.0.0.0 Safari/537.36"


class SourceError(ValueError):
    pass


def matches_football(sport, league, title):
    if not sport.startswith("Calcio"):
        return True
    # shortcut: genere ricavato dai nomi della fonte, aggiornare i termini se cambia la classificazione.
    female = bool(re.search(r"women|female|femen|femmin|frauen|\b(?:nwsl|wsl|liga f)\b|\bW\b", league + " " + title, re.I))
    return female == (sport == "Calcio femminile")


def event_image(sport, base, *candidates):
    for value in candidates:
        if isinstance(value, str) and value.strip():
            try:
                return http_url(urljoin(base, value))
            except ValueError:
                pass
    return str(Path(__file__).parent / "resources" / (SPORTS[sport] + ".png"))


def http_url(value):
    parsed = urlsplit(value)
    if parsed.scheme not in ("http", "https") or not parsed.hostname or any(c in value for c in "\r\n"):
        raise SourceError("Invalid source URL.")
    return value


def fetch_page(url, referer=""):
    request = Request(http_url(url), headers={"User-Agent": USER_AGENT, "Referer": referer})
    try:
        with urlopen(request, timeout=15) as response:
            data = response.read(2 * 1024 * 1024 + 1)
            if len(data) > 2 * 1024 * 1024:
                raise SourceError("Source response is too large.")
            return data.decode("utf-8"), response.geturl()
    except HTTPError as exc:
        raise SourceError("Source HTTP {}. The link may be unavailable.".format(exc.code)) from exc
    except URLError as exc:
        if isinstance(exc.reason, SSLCertVerificationError):
            raise SourceError("The source HTTPS certificate could not be verified. Check the device date or try another provider.") from exc
        raise SourceError("The source is unreachable. Try again later.") from exc
    except (OSError, UnicodeError) as exc:
        raise SourceError("The source is unreachable. Try again later.") from exc
