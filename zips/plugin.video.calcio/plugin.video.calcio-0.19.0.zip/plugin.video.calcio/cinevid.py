"""Cinevid public event catalog; web embeds are not Kodi video streams."""
import json
import re
from datetime import datetime, timezone
from urllib.parse import urljoin, urlsplit

from events import SourceError, fetch_page, event_image, matches_football

BASE = "https://cinevid.st/"
SPORTS = {"Calcio maschile":"Football", "Calcio femminile":"Football", "Pallavolo":"Volleyball",
          "Football americano":"American Football", "Basket":"Basketball", "Hockey":"Ice Hockey",
          "Baseball":"Baseball", "UFC":"Fighting", "F1":"Motorsport"}


def get_events(sport):
    try:
        data = json.loads(fetch_page(BASE + "api/public/events", BASE)[0])
        if not isinstance(data, dict) or not isinstance(data.get("events"), list):
            raise ValueError()
    except (ValueError, OSError) as exc:
        if isinstance(exc, SourceError):
            raise
        raise SourceError("Invalid Cinevid event catalog.") from exc
    result = []
    seen = set()
    for row in data["events"]:
        if not isinstance(row, dict) or row.get("sport") != SPORTS[sport] or row.get("status") not in ("NS", "Live"):
            continue
        key, title, league = row.get("id"), row.get("title"), str(row.get("league") or "")
        if not isinstance(key, str) or not re.fullmatch(r"[0-9]{1,30}", key) or key in seen or not isinstance(title, str) or not title.strip():
            continue
        if not matches_football(sport, league, title) or (sport == "UFC" and "UFC" not in league.upper()) or (sport == "F1" and not re.search(r"\bF1\b|FORMULA (?:1|ONE)", league, re.I)):
            continue
        try:
            # shortcut: source dates have no offset; use UTC until the API supplies one.
            date = datetime.fromisoformat(row["date"] + "T" + row["time"]).replace(tzinfo=timezone.utc).astimezone()
        except (KeyError, TypeError, ValueError, OverflowError, OSError):
            continue
        player = row.get("playerUrl")
        try:
            player = urljoin(BASE, player) if isinstance(player, str) and not any(c in player for c in "\r\n") else ""
            parsed = urlsplit(player)
            if parsed.scheme != "https" or parsed.netloc != "cinevid.st" or parsed.path != "/embed/live/" + key or parsed.query or parsed.fragment:
                player = ""
        except ValueError:
            player = ""
        result.append({"key":"cinevid:" + key, "title":title.strip(), "sport":sport, "league":league.strip() or "Other competitions",
                       "time":date.strftime("%d/%m %H:%M"), "timestamp":date.timestamp(), "player":player,
                       "image":event_image(sport, BASE, row.get("thumbnail"), row.get("homeTeamImage"), row.get("awayTeamImage"))})
        seen.add(key)
    return sorted(result, key=lambda row: (row["timestamp"], row["key"]))


def get_sources(key, sport):
    if not isinstance(key, str) or not re.fullmatch(r"cinevid:[0-9]{1,30}", key):
        raise SourceError("Invalid Cinevid event ID.")
    row = next((row for row in get_events(sport) if row["key"] == key), None)
    if not row:
        raise SourceError("This event has left the Cinevid schedule. Reopen the category.")
    if row["player"]:
        raise SourceError("Cinevid provides a web player. This public API does not expose a video stream compatible with Kodi.")
    return []


def resolve_event(key, sport, source_index=0, source_url=None):
    sources = get_sources(key, sport)
    if source_url is not None and source_url not in sources:
        raise SourceError("The selected player is no longer available. Reopen the match.")
    if not 0 <= source_index < len(sources):
        raise SourceError("No Cinevid player is available for this event.")
    raise SourceError("Cinevid provides a web player. This public API does not expose a video stream compatible with Kodi.")
