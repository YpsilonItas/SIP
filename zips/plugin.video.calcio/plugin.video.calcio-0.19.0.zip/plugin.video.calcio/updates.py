"""Ask Kodi to refresh enabled repositories once per session."""
import xbmc
import xbmcgui


def check_updates():
    window = xbmcgui.Window(10000)
    if window.getProperty("sip.updates.checked") != "true":
        xbmc.executebuiltin("UpdateAddonRepos")
        window.setProperty("sip.updates.checked", "true")
